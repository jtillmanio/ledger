# Status

_Update this in the same PR you tick a task in `TASKS.md`. This is what a new
chat reads to resume — `HANDOFF.md` is deep background, read only for "why."_

**Phase:** 0 — Foundation
**Next task:** 0.1 Test harness (S) — blocks 0.2 CI and everything after it
**Done in Phase 0:** 0.6 (derived run span, cover dates, reviewed whys), 0.7
(one issue per comic, credits, story titles, label review) — built during the
ETL/enrichment pass, ahead of the formal task sequence
**Not started:** 0.1–0.5, and all of Phases 1–8 (see `TASKS.md`)
**Deployed:** nothing yet. No tests exist yet — that's task 0.1.

## Three things costliest to get wrong

Full reasoning in `HANDOFF.md` §10.

1. **Task 1.5 (`read_events`) must land before real reading data accumulates.**
   A second read currently overwrites the first, and that history can't be
   reconstructed.
2. **Don't cut over from Sheets before Phase 1 finishes.** Bulk entry has to
   exist, or adding a run is slower than the spreadsheet.
3. **Never let a deploy auto-migrate.** Vercel builds on every push, and there
   is no undo.

## To resume in a new chat

> Read STATUS.md and CLAUDE.md. I'm working on task &lt;id&gt;. Don't write
> anything until I confirm the plan.

Only pull in `HANDOFF.md` (why a decision was made) or `START-HERE.md`
(re-running a runbook step) if this file doesn't have what you need.
