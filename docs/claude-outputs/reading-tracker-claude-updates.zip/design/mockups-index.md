# Mockup screen index

`design/mockups.html` is ~288KB for 23 screens (phone + desktop, light + dark).
Don't `@mention` or `Read` the whole file for one screen — use
`scripts/screen.sh <id>` (or `scripts/screen.ps1 <id>` on native PowerShell),
which greps the live file for `data-id="<id>"` and prints just that
`<section>...</section>`, notes included.

This table is for humans — which id is which screen. The scripts always
compute the line range fresh from the file, so it can't go stale even if the
line numbers below drift after an edit.

| id | Screen | Approx. lines (v4, may drift) |
|---|---|---|
| `home` | Comics dashboard | 485–715 |
| `runs` | Run list | 718–795 |
| `spine` | Run detail | 798–903 |
| `range` | Range marking | 906–984 |
| `bulk` | Bulk add | 987–1066 |
| `newrun` | New run | 1069–1163 |
| `ai` | AI review | 1166–1253 |
| `bdash` | Books dashboard | 1256–1412 |
| `plan` | Plan by quarter | 1415–1550 |
| `moveplan` | Move / add to a quarter | 1553–1690 |
| `blist` | Master list | 1693–1786 |
| `add` | Add books | 1789–1869 |
| `shelves` | Shelves | 1872–1959 |
| `top` | Top books | 1962–2040 |
| `search` | Search | 2043–2145 |
| `stats` | Stats | 2149–2387 |
| `capture` | Quick capture | 2390–2479 |
| `watchlist` | Watch dashboard | 2483–2626 |
| `franchise` | Franchises | 2629–2747 |
| `watchadd` | Search and add | 2750–2842 |
| `bookdetail` | Book detail — a sheet, not a hover | 2845–2994 |
| `titledetail` | Show detail — seasons | 2997–3139 |
| `settings` | Settings | 3142–3251 |

Average screen is ~120 lines / ~12KB — reading one instead of the whole file
is a ~20x cut for the single most common lookup in this repo (every task in
`TASKS.md` that touches a screen references this file).

If you add a 24th screen, give its `<section>` a `data-id="..."` like the
others and add a row here — the id is all `scripts/screen.*` needs; the line
numbers are decoration.
