---
paths:
  - "src/db/**"
  - "etl/**"
  - "drizzle/**"
  - "seed/**"
---

# Schema and data-model rules

Loads automatically when you're touching the database layer, ETL, migrations,
or seed data — not on every session. See `CLAUDE.md` for what's true
everywhere else.

- **Derived data is never stored.** Readiness, completion percentages, track
  rollups, and capacity live in `etl/views.sql`. If you find yourself adding a
  `completed_count` column, stop — it belongs in a view.
- **A run's series text and years are derived, never stored.** `runs` has no
  `series_issues`, `start_year` or `end_year`. The `run_span` view builds the
  series text from the issue labels (grouped by series and volume, ranges
  collapsed) and the years from the earliest and latest `issues.cover_date`.
  Read them through `run_span`; never format them in the app and never add them
  back as columns. `dated_issues < issue_count` means the span is incomplete.
- **Issue metadata and whys come from sidecar files, not the workbook.** They sit
  beside `volume_map.csv` and survive every re-extract:
  `cover_dates.csv` (label; `source` metron|hand), `issue_details.csv` (label;
  story title with `story_title_source`, cover URL), `issue_credits.csv` (label,
  creator, role; `source` metron|hand), `label_review.csv` (label → proposed
  label; `decision` accept|reject) and `why_review.csv` (run id; `decision`
  accept|edit|keep). `etl/enrich_comics.py` writes the first four and never
  overwrites a `hand` value; a `(label, role)` pair with any hand credit is left
  alone entirely.
- **A label changes only through an accepted label review.** Enrich proposes
  Metron's canonical label; extract applies a rename only when `decision` is
  `accept`, and enrich rekeys every sidecar to the new label on its next run.
  Nothing ever writes back to the workbook.
- **One issue row per comic.** `issues` is what exists — one row per label, id a
  slug of the label, never a run position. `run_issues(run_id, sequence,
  issue_id, type, notes)` is where it sits in a run; `type` and `notes` belong to
  the placement. The same issue in four runs is one `issues` row and four
  `run_issues` rows. Progress and credits key on `issues.id`, so reading it once
  reads it everywhere. Totals above a run count `DISTINCT issue_id`; never SUM
  run totals across runs.
- **A run's writers and artists are derived, never stored.** `runs` has no
  `writer` or `artists`. Read them from `run_credit_line` (creators on ≥25% of
  the run's credited issues, max three), built from `issue_credits` via
  `run_creators`. There is no hand-typed fallback — to fix a credit line, fix
  the issue credits.
- **A why is authored, so it is stored.** `runs.why_source` is `hand` or
  `claude`. `hand` means Justin wrote or edited it and nothing automated may
  replace it. `claude` means a Claude draft accepted as-is; it may be
  re-proposed for review, never silently rewritten.
- **A plan entry's year is derived from its period, never stored beside it.**
  `reading_plan.period` is one text column — `2027-Q1`, `2027-03`, `2027`, or
  `someday` — and the year is `left(period, 4)`. An entry with a bare year is
  legitimately unscheduled (175 of them came over from the workbook); an entry
  whose year and quarter could disagree is a bug the schema should not allow.
  Read year/quarter/month through the `plan_period` view, never by parsing in
  the app.
- **Blocks group runs inside a track; eras section issues inside a run.** Both
  are tables, both are optional, and both are ordered — `blocks(track_id,
  number, name?)` and `eras(run_id, ordinal, name)`. Era membership goes on the
  placement (`run_issues.era_id`), not the issue. A block is a position, so
  it is numbered and may be unnamed. An era is a story, so it is named. A run
  with no block renders a two-rail telescope; a run with no eras renders a flat
  spine. Neither is an error.
- **Catalog and progress are separate.** `issues` is what exists, `issue_progress`
  is what Justin read. Every progress table is keyed `(user_id, entity_id)`.
  Never add a per-user boolean to a catalog table.
- **`postgres.js` needs `prepare: false`** — Neon runs a transaction-mode pooler.
- Run IDs are hand-authored slugs (`hickman-ff`). Never regenerate them.
- Runs with `placeholder = true` are forward-declared prereq targets. Hide them
  from run lists; keep their edges.
- Soft delete only. `deleted_at IS NULL` on every read. A hard delete on `runs`
  cascades to issues and prereq edges.
- Enrichment scripts never overwrite a hand-entered value.
- Metron, Open Library and Hardcover are backfill-only, never on the request
  path. TMDB is the exception: called live during search, cached into `titles`
  on first add. TMDB attribution belongs in the footer.
- Shelves hold books or titles, never runs, and never both at once —
  `shelves.kind` is `books` or `titles`, with `shelf_books` / `shelf_titles`
  each carrying a real non-null foreign key. Don't reintroduce a polymorphic
  `shelf_items` table: a nullable-FK row needs a `num_nonnulls` check to stay
  honest, and every read needs a CASE. Two narrow tables cost one join and
  nothing else.
- The watchlist tracks seasons, never episodes. Show state is derived from
  `season_status` via the `show_progress` view — never write a show-level status
  to `title_status`. Films use `title_status` directly.
- Franchises are facts about the work (TMDB collections plus curation); shelves
  are the user's opinion. Different tables, don't merge them.
- IMPORTANT: AI-generated issue labels never reach the database without passing
  the bulk-entry parser, a Metron existence check, and an explicit user accept.
  Metron-proposed labels (`label_review.csv`) follow the same rule: explicit
  accept only.
- **The database is disposable until cutover.** `npm run rebuild` drops and
  reloads everything. `.env` `LEDGER_LIVE=true` (set at START-HERE Step 14)
  makes it refuse. Never suggest a rebuild or `load.ps1` once that is set.
- `etl/extract.py` is the migration from the workbooks. Changing its output
  format means re-running against both `.xlsx` files and diffing the CSVs.
