---
paths:
  - "src/app/**"
  - "src/components/**"
  - "design/**"
---

# Design and UI rules

Loads automatically when you're touching a screen, component, or the mockups
— not on every session. See `CLAUDE.md` for what's true everywhere else.

## Design

`design/mockups.html` (v4) is the reviewed layout and copy for every screen.
Match it. It is annotated with the reasoning behind each decision; read the
notes column before changing a layout. Where a task description and the mockup
disagree, the mockup wins. Pull up one screen with `scripts/screen.sh <id>`
(ids in `design/mockups-index.md`) rather than reading the whole file.

Phone at 360–412px is the primary device and every screen is designed there
first. A desktop layout that a phone layout degrades into is the wrong answer.

- **One dashboard per medium**, not one dashboard for everything. `/comics`,
  `/books`, `/watch`. `/` redirects to whichever you touched last. List screens
  sit one level down (`/comics/runs`, `/books/list`).
- **Every dashboard has the same five slots in the same order**: now → next,
  with a control on it → position → situation → a compact rollup → the thumb
  bar. What differs between media is what fills a slot, not the order.
- **The thumb bar is fixed at the bottom of every dashboard and the run
  detail**, same position, same primary verb slot. Marking what you just read
  is one tap and reachable with a thumb. Nothing displaces it.
- **Position is drawn, not counted.** Three nested positions (issue in run, run
  in block, block in track) render as the telescope, not as three percentages.
  Books get the same instinct applied to time: the plan rail.
- **Never draw progress against the catalog.** 76 of 10,273 as a bar is a lie
  told with a rectangle. Comics measure against the run and the block; the
  catalog total appears once, small, as provenance.
- **Detail views are intercepted routes, not modal components:** a sheet from a
  list, a full page on direct load. The back button must dismiss.

## Style

- Plain CSS with the custom properties in `src/app/globals.css`. No Tailwind, no
  CSS-in-JS. The token set there is the same one as `design/mockups.html`.
- **Colour is functional, and there are exactly four meanings.** `--ready`
  green is read/done. `--brand` blue is where you are, and the primary action.
  `--blocked` amber is *held* — either a hard prerequisite is unread or a
  decision has not been made (over capacity, no quarter chosen). `--danger` red
  is destructive actions and validation failures only. **Nothing on a dashboard
  is ever red.** `--t1`–`--t8` carry track and genre identity and nothing else.
  Anything without a meaning stays grey.
- **Amber clears when the user decides, including when they decide to keep the
  overage.** Accepting an over-committed year is a first-class outcome that
  persists. An indicator you cannot dismiss by choosing is one people stop
  reading.
- `--mark` and `--held` survive as aliases for `--ready` and `--blocked` so the
  first three routes keep rendering. New code uses the real names.
- Server components by default. Client components only where there is state.
- Raw SQL in `src/db/queries.ts` for anything joining views; Drizzle builder for
  writes. (This one crosses into `src/db/` — see `.claude/rules/schema.md` too
  if the query itself is what you're changing.)
