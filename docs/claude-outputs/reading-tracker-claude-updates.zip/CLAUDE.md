# Reading ledger

Personal reading tracker replacing two Google Sheets. About 10,270 distinct comic
issues in 10,840 run placements across 259 runs with a prerequisite DAG, plus
1,478 books. Single user, multi-user schema.

Read `STATUS.md` first — current phase, next task, the three things costliest
to get wrong. `HANDOFF.md` is deep background (the *why*, not the *what*);
read it only when you need the reasoning behind a decision. `TASKS.md` is the
backlog, `FEATURES.md` is scope, `ARCHITECTURE.md` is why the schema looks
like this, `DIAGRAMS.md` is visual. `START-HERE.md` is the human's runbook —
don't run its commands unless asked.

Development happens on Windows in PowerShell. Prefer `py` over `python`, and
`.\etl\load.ps1` over `etl/load.sh`. psql `\copy` paths need forward slashes
even on Windows.

## Commands

```powershell
npm run dev                 # local, needs .env
npm test                    # vitest, needs a running Postgres
npx tsc --noEmit             # typecheck
npm run db:generate         # after editing src/db/schema.ts
npm run db:push             # apply migration
npm run db:views            # re-apply etl/views.sql — REQUIRED after schema changes
npm run extract             # etl/extract.py with every sidecar CSV (see below)
py etl/enrich_comics.py     # Metron: dates, cover URLs, label proposals (--dry-run first)
py etl/enrich_comics.py --details  # Metron: story titles + credits, ~8,100 requests (--dry-run first)
.\etl\load.ps1              # PowerShell loader; etl/load.sh is the WSL/Git Bash twin
npm run rebuild             # drop, migrate from zero, extract, load, test_views, row counts
                            # etl/rebuild.ps1; refuses when LEDGER_LIVE=true; twin etl/rebuild.sh
npm run test:views          # etl/test_views.sql: SQL assertions, rolls back, safe on a loaded DB
npm run test:etl            # py -m unittest over etl/test_*.py, no network
```

## Extract a section instead of reading the whole file

`TASKS.md` (43KB) and `design/mockups.html` (288KB) are reference files you
almost always need one piece of, not all of:

- One task: `bash scripts/task.sh 1.3` (`scripts/task.ps1 1.3` on native
  PowerShell) — prints just that task's block.
- One screen: `bash scripts/screen.sh bulk` (`scripts/screen.ps1 bulk`) —
  prints just that `<section>`. IDs are in `design/mockups-index.md`.

Don't `@mention` either file whole for a single section — that loads every
byte, every time. A hook blocks a whole-file `Read` of `design/mockups.html`
and of the generated CSVs under `seed/` for the same reason; query data files
with `psql`/`head`/`grep` instead of reading them.

## Rules that only apply to part of the repo

Schema and data-model rules live in `.claude/rules/schema.md` — they load
automatically when you touch `src/db/`, `etl/`, `drizzle/`, or `seed/`.
Design and UI rules live in `.claude/rules/ui.md` — they load automatically
for `src/app/`, `src/components/`, or `design/`. Edit those files, not this
one, for anything scoped to those paths — this file is only for what's true
everywhere, every session.

## Workflow

- Branch `task/<id>-<slug>`, one PR per task in `TASKS.md`, squash merge.
- IMPORTANT: no task merges without a test that would have failed before it.
- Tick the task's checkbox in `TASKS.md` and update `STATUS.md` in the same PR.
