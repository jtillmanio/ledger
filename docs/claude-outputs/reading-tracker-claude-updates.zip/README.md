# Reading ledger

A private tracker for three media types.

| | |
|---|---|
| **Comics** | 10,273 issues placed 10,840 times across 259 runs, with a prerequisite graph 24 levels deep and creator credits from Metron |
| **Books** | 1,480 titles with per-year planning, word-count capacity budgeting, and series completion |
| **Film & TV** | TMDB-backed watchlist — franchises, shows, seasons. Starts empty |

Replaces two Google Sheets that outgrew being spreadsheets: the comics workbook
was a three-table relational schema simulated with `COUNTIFS`, and its
dependency graph needed a recursive CTE that Sheets couldn't provide.

---

## Where to start

**Resuming a session, day to day? → [STATUS.md](STATUS.md)**
**New here, or need the reasoning behind a decision? → [HANDOFF.md](HANDOFF.md)**
**Ready to build? → [START-HERE.md](START-HERE.md)**

Every other document is reference. None of them need reading front to back.

| Document | Its one job | Read it when |
|---|---|---|
| **[STATUS.md](STATUS.md)** | **Where things stand.** Current phase, next task, the three costliest gotchas | Resuming any session. This is the default, not `HANDOFF.md` |
| **[START-HERE.md](START-HERE.md)** | **The linear runbook.** Unzip → install → migrate → deploy → build → cut over. Every command, in order | You're doing the work. This is the only doc you read top to bottom |
| **[HANDOFF.md](HANDOFF.md)** | **Full project context.** Objectives, every decision and why, data findings, what's open | You need the *reasoning* behind a decision, not just the current state |
| **[CLAUDE-CODE.md](CLAUDE-CODE.md)** | **Technique, not sequence.** How to drive Claude Code — the loop, hygiene, model choice, prompts, review standards | Before your first build session, then by section |
| **[TASKS.md](TASKS.md)** | **The backlog.** 51 tasks in 9 phases, each with a pass/fail check | Every build session. One task at a time — pull it with `scripts/task.sh <id>`, don't read the whole file |
| **[FEATURES.md](FEATURES.md)** | **Scope and rationale.** What's in, what's out, metadata APIs, metrics, schema additions | Deciding what to build, or looking up a schema addition |
| **[design/mockups.html](design/mockups.html)** | **23 annotated screens.** Authoritative for layout and copy | Building any screen — pull one with `scripts/screen.sh <id>` (ids in [design/mockups-index.md](design/mockups-index.md)), don't read the whole file |
| **[DIAGRAMS.md](DIAGRAMS.md)** | **Visual reference.** ERDs, derived layer, runtime, validation pipeline | Orienting to the schema or a data flow |
| **[ARCHITECTURE.md](ARCHITECTURE.md)** | **The reasoning.** Why the schema looks like this, what each sheet artifact became | Questioning a structural decision |
| **[CLAUDE.md](CLAUDE.md)** | **Session context.** Auto-loaded by Claude Code | Never directly — it loads itself |

**No command appears in two documents.** Anything sequential lives in
`START-HERE.md`.

---

## What's in the box

```
START-HERE.md      the runbook — start here to build
HANDOFF.md         full project context — deep background, not the daily resume
STATUS.md          where things stand — read this to resume, day to day
CLAUDE-CODE.md     how to drive Claude Code
TASKS.md           51 tasks, 9 phases, each with an acceptance check
FEATURES.md        scope, APIs, metrics, schema additions
DIAGRAMS.md        11 Mermaid diagrams
ARCHITECTURE.md    schema rationale and sheet-to-table mapping
CLAUDE.md          auto-loaded session context

design/
  mockups.html     23 annotated screens, phone + desktop, light + dark
  mockups-index.md screen id -> name, for scripts/screen.* and for humans

scripts/
  task.sh/.ps1     print one task from TASKS.md instead of the whole file
  screen.sh/.ps1   print one screen from mockups.html instead of the whole file

etl/
  extract.py       Sheets export + sidecar CSVs -> normalized CSVs, with an unresolved report
  volumes.py       proposes a volume year for labels written without one
  enrich_comics.py Metron backfill: dates, covers, label proposals, story titles, credits
  views.sql        every formula column from the workbook, as Postgres views
  load.ps1         psql loader for Windows, idempotent
  load.sh          the same loader for WSL, Git Bash, macOS, Linux
  rebuild.ps1      drop, migrate, extract, load, verify — until cutover (+ rebuild.sh)

src/
  db/schema.ts     23 tables; catalog shared, progress keyed by user
  db/queries.ts    every read the UI performs
  app/             dashboard, runs, run detail with check-off, books, login

volume_map.csv     67 approved volume-year rules across 61 series
cover_dates.csv    Metron + hand cover dates, keyed by issue label
issue_details.csv  story titles and cover URLs, keyed by issue label
issue_credits.csv  creator credits by role, keyed by issue label
label_review.csv   Metron-proposed label fixes awaiting your accept
why_review.csv     drafted whys awaiting your decision
.claude/           settings.json (context-guard hook), rules/ (schema.md, ui.md),
                   /verify skill, schema-reviewer subagent (pinned to Sonnet)
.github/workflows/ CI and nightly pg_dump backup
```

---

## Stack

Next.js 15 · Postgres on Neon · Drizzle · Vercel Hobby · plain CSS.
**$0/month.**

## Quick start

The full version with verification steps is `START-HERE.md`. The short form:

```powershell
Copy-Item .env.example .env; notepad .env
npm install
npm run rebuild -- -Yes      # migrate, extract, load, verify
npm run dev
```

macOS, Linux, or WSL: `py` → `python3`, and `npm run rebuild` → `bash etl/rebuild.sh --yes`.

## Three things not to get wrong

1. **Task 1.5 (`read_events`) must land before real reading data accumulates.**
   A second read currently overwrites the first, and that history cannot be
   reconstructed.
2. **Do not cut over from Sheets before Phase 1 finishes.** Bulk entry has to
   exist, or adding a run is slower than the spreadsheet.
3. **Never let a deploy auto-migrate.** Vercel builds on every push, and there
   is no undo.
